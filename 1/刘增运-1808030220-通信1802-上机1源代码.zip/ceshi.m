clc,clear,close all

% p=[1/4,1/4,1/4,1/4];
% p=[0.1,0.2,0.3,0.4];
% p=[0.2,0.2,0.3,0.3];
% p=[0.2,0.2,0.2,0.2,0.2];
% p=[0.3,0.3,0.2,0.1,0.1];
 p=[0.3,0.25,0.2,0.15,0.1];
% p=[1/7,1/7,1/7,1/7,1/7,1/7,1/7];
format compact
dingchangbianma(p);
xiangnongbianma(p);
hafumanbianma(p);

